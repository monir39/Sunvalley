(function($){
	$(document).ready(function(){

		 var swiper = new Swiper('.swiper-container', {
		      direction: 'vertical',
		      pagination: {
		        el: '.swiper-pagination',
		        clickable: true,
		      },
		    });
	});
})(jQuery);